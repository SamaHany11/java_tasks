package sama_tasks;

public class base {
	private int id;
	private String name;
	void setid(int id) {
		this.id=id;
	}
	void setname(String name) {
		this.name=name;
	}
	String getname() {
		return name;
	}
	int getid() {
		return id;
	}
}
