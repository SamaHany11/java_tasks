package sama_tasks;

public class Employee extends data{
	private int no;
	private String name;
	
	void setno(int no) {
		this.no=no;
	}
		int getno() {
			return no;
		}
}
