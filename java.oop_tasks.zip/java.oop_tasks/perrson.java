package sama_tasks;

public class perrson extends base {
	private int id;
	private String name;
}
