package sama_tasks;

public class data extends base {
private String phone;
}
