package sama_tasks;

public class Student extends data {
private int id;
private String name;
private int age;

void setage(int age) {
	this.age=age;
}

int getage() {
	return age;
}
void sum(int n1,int n2) {
	 System.out.println(n1+n2);
}
}
